 let user = [{
    "Id" : 1 ,
    "name" : "Jannindu" ,
    "sex" : "never"
 } ,

 {
    "Id" : 2 ,
    "name" : "Sarindu" ,
    "sex" : "sometimes"
 },

 {
    "Id" : 3 ,
    "name" : "Kithmina" ,
    "sex" : "Always"
 }
]

export default user;